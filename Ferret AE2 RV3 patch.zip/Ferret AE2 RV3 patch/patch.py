import os
import sys
import shutil
from zipfile import ZipFile
print('modpack dir?')
dir = raw_input('>: ')
try:
    shutil.copy('patch.zip',dir + '\mods')
except:
    shutil.copy('patch.zip',dir + '\mods')
try:
    os.chdir(dir + '\mods')
except:
    os.chdir(dir + 'mods')
with ZipFile('patch.zip') as file:
    file.extractall()
print "done! cleaning up..."
os.remove('patch.zip')
print('finished!')
raw_input('')