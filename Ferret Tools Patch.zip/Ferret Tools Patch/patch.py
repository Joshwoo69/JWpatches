import os
import sys
import shutil
from zipfile import ZipFile
shutil.copy('patch.zip','..\Curse\Instances\The Ferret Business\mods\patch.zip')
os.chdir('..\Curse\Instances\The Ferret Business\mods')
with ZipFile('patch.zip') as file:
    file.extractall()
print "done! cleaning up..."
os.remove('patch.zip')
print('finished!')